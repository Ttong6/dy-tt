package io.github.dyfloatbar;

import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.animation.DecelerateInterpolator;

/**
 * 实心胶囊 + 极细描边 + 选中项后面一块更浅/更深的胶囊（会滑动）。
 * 没有模糊、半透明、高光，不是玻璃态。
 * 深色页面用视频里的配色，浅色页面用反相配色，这样 App 自己设置的文字/图标颜色始终可读。
 */
public class FloatingBarDrawable extends Drawable {
    // 深色（取自视频帧采样）
    static final int DARK_BAR = 0xFF141414, DARK_STROKE = 0xFF282828, DARK_IND = 0xFF343436;
    // 浅色
    static final int LIGHT_BAR = 0xFFF4F4F5, LIGHT_STROKE = 0xFFE2E2E4, LIGHT_IND = 0xFFE0E0E3;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ind = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float strokeW;
    private final float vInset;

    private float indL = -1, indR = -1;
    private ValueAnimator anim;
    private boolean dark = true;

    FloatingBarDrawable(float density) {
        stroke.setStyle(Paint.Style.STROKE);
        strokeW = Math.max(1f, density);
        stroke.setStrokeWidth(strokeW);
        vInset = 6 * density;
        applyColors();
    }

    private void applyColors() {
        fill.setColor(dark ? DARK_BAR : LIGHT_BAR);
        stroke.setColor(dark ? DARK_STROKE : LIGHT_STROKE);
        ind.setColor(dark ? DARK_IND : LIGHT_IND);
    }

    /** @return 是否发生了变化 */
    boolean setDark(boolean d) {
        if (d == dark) return false;
        dark = d;
        applyColors();
        invalidateSelf();
        return true;
    }

    boolean hasIndicator() { return indR > indL; }

    /** 把选中块移到 [l, r]（相对 drawable 左边界）。 */
    void moveIndicator(final float l, final float r, boolean animate) {
        if (indR > indL && Math.abs(indL - l) < 0.5f && Math.abs(indR - r) < 0.5f) return;
        if (anim != null) anim.cancel();
        if (!animate || !hasIndicator()) {
            indL = l; indR = r; invalidateSelf();
            return;
        }
        final float l0 = indL, r0 = indR;
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(220);
        anim.setInterpolator(new DecelerateInterpolator(1.6f));
        anim.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            indL = l0 + (l - l0) * t;
            indR = r0 + (r - r0) * t;
            invalidateSelf();
        });
        anim.start();
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float radius = b.height() / 2f;
        rect.set(b);
        c.drawRoundRect(rect, radius, radius, fill);

        if (hasIndicator()) {
            rect.set(b.left + indL, b.top + vInset, b.left + indR, b.bottom - vInset);
            float ir = rect.height() / 2f;
            c.drawRoundRect(rect, ir, ir, ind);
        }

        float h = strokeW / 2f;
        rect.set(b.left + h, b.top + h, b.right - h, b.bottom - h);
        c.drawRoundRect(rect, radius - h, radius - h, stroke);
    }

    @Override public void setAlpha(int alpha) { }
    @Override public void setColorFilter(ColorFilter cf) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
