package io.github.dyfloatbar;

import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 抖音 40.6.0 (40600200) 悬浮胶囊底栏 —— 类名/资源 id 已按该版本 APK 写死。
 *
 * 底栏结构（从 dex + 布局 r/zfh.xml 解出）：
 *   X.0dx5  (FrameLayout, "MainBottomTabViewNew")            ← 底栏本体，App 在这上面设置页面底色
 *    └ FrameLayout  id 0x7f0a0c61
 *        ├ DuxImageView  0x7f0a144b          皮肤背景图
 *        ├ ViewStub      0x7f0ad746
 *        └ LinearLayout  0x7f0a172a (竖)      = X.0dx5.d
 *            ├ View        0x7f0a75d9         0.5dp 顶部分割线
 *            └ LinearLayout 0x7f0a7983 (横)   ← 标签行：胶囊就画在这里
 *                └ BottomTab × N              (X.0du7 → FrameLayout)，isSelected() 读 X.0du7.d
 *
 * 性能：全部事件驱动，只 hook 三个方法，没有任何每帧回调/遍历。
 *   1) X.0dx5.onAttachedToWindow       安装一次
 *   2) X.0dx5.setBackgroundDrawable    App 切页面主题（深/浅）时才触发，用来切换胶囊配色
 *   3) X.0du7.setSelected(boolean)     切 tab 时才触发，合并到一次 post 里移动选中块
 */
public class MainHook implements IXposedHookLoadPackage {

    static final String PKG = "com.ss.android.ugc.aweme";

    // ---- 40.6.0 写死的类名 / id ----
    static final String CLS_BAR = "X.0dx5";
    static final String CLS_TAB_BASE = "X.0du7";
    static final String CLS_TAB = "com.ss.android.ugc.aweme.homepage.tab.ui.bottom.BottomTab";
    static final int ID_ROW = 0x7f0a7983;
    static final int ID_DIVIDER = 0x7f0a75d9;

    // ---- 可调参数 (dp) ----
    static final int SIDE_MARGIN = 26;
    static final int INDICATOR_H_INSET = 4;

    static final String FIELD = "dyfb";
    static Class<?> tabClass;

    static final class State {
        FloatingBarDrawable d;
        ViewGroup row;
        boolean dark = true;
        boolean pending;
        final Runnable update = new Runnable() {
            @Override public void run() { pending = false; updateIndicator(State.this, true); }
        };
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpp) {
        if (!PKG.equals(lpp.packageName)) return;
        try {
            ClassLoader cl = lpp.classLoader;
            Class<?> bar = XposedHelpers.findClassIfExists(CLS_BAR, cl);
            Class<?> tabBase = XposedHelpers.findClassIfExists(CLS_TAB_BASE, cl);
            tabClass = XposedHelpers.findClassIfExists(CLS_TAB, cl);
            if (bar == null || tabBase == null || tabClass == null) {
                XposedBridge.log("[DYFB] 未找到底栏类，抖音版本不是 40.6.0？已跳过");
                return;
            }

            XposedHelpers.findAndHookMethod(bar, "onAttachedToWindow", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try { install((ViewGroup) p.thisObject); }
                    catch (Throwable t) { XposedBridge.log("[DYFB] install: " + t); }
                }
            });

            XposedHelpers.findAndHookMethod(bar, "setBackgroundDrawable", Drawable.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try { onBackground((View) p.thisObject, (Drawable) p.args[0]); }
                    catch (Throwable t) { XposedBridge.log("[DYFB] bg: " + t); }
                }
            });

            XposedHelpers.findAndHookMethod(tabBase, "setSelected", boolean.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    try { onSelected((View) p.thisObject); }
                    catch (Throwable t) { XposedBridge.log("[DYFB] sel: " + t); }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("[DYFB] hook failed: " + t);
        }
    }

    // ------------------------------------------------------------ 安装（一次）

    static void install(ViewGroup bar) {
        State st = (State) XposedHelpers.getAdditionalInstanceField(bar, FIELD);
        if (st == null) {
            st = new State();
            XposedHelpers.setAdditionalInstanceField(bar, FIELD, st);
        }
        if (st.row != null) return;

        View r = bar.findViewById(ID_ROW);
        if (!(r instanceof ViewGroup)) {
            XposedBridge.log("[DYFB] 找不到标签行 0x7f0a7983");
            return;
        }
        final ViewGroup row = (ViewGroup) r;
        final float den = bar.getResources().getDisplayMetrics().density;
        final State s = st;

        s.row = row;
        s.d = new FloatingBarDrawable(den);
        s.d.setDark(s.dark);
        XposedHelpers.setAdditionalInstanceField(row, FIELD, s);

        View divider = bar.findViewById(ID_DIVIDER);
        if (divider != null) divider.setVisibility(View.GONE);

        row.setBackground(s.d);
        ensureMargins(row, den);

        // 只在行自己重新布局时触发（宽度变化 / 子 View 增减），不是每帧
        row.addOnLayoutChangeListener((v, l, t, rr, b, ol, ot, or, ob) -> {
            ensureMargins(row, den);
            updateIndicator(s, false);
        });

        // 用 App 当前已设置的底色决定初始配色
        Drawable bg = bar.getBackground();
        if (bg != null) onBackground(bar, bg);
        schedule(s);
    }

    static void ensureMargins(ViewGroup row, float den) {
        ViewGroup.LayoutParams lp = row.getLayoutParams();
        if (!(lp instanceof ViewGroup.MarginLayoutParams)) return;
        ViewGroup.MarginLayoutParams m = (ViewGroup.MarginLayoutParams) lp;
        int side = (int) (SIDE_MARGIN * den + 0.5f);
        if (m.leftMargin != side || m.rightMargin != side) {
            m.leftMargin = side;
            m.rightMargin = side;
            row.setLayoutParams(m);
        }
    }

    // ------------------------------------------------------------ 主题（深/浅）

    static void onBackground(View bar, Drawable bg) {
        if (!(bg instanceof ColorDrawable)) return;
        State st = (State) XposedHelpers.getAdditionalInstanceField(bar, FIELD);
        if (st == null) return;
        int c = ((ColorDrawable) bg).getColor();
        int a = c >>> 24;
        float luma = (0.299f * ((c >> 16) & 0xff) + 0.587f * ((c >> 8) & 0xff) + 0.114f * (c & 0xff)) / 255f;
        // 近乎透明时底下是视频，App 用的是白字 → 深色胶囊
        boolean dark = a < 0x80 || luma < 0.5f;
        st.dark = dark;
        if (st.d != null) st.d.setDark(dark);
    }

    // ------------------------------------------------------------ 选中块

    static void onSelected(View tab) {
        ViewParent p = tab.getParent();
        if (p == null) return;
        State st = (State) XposedHelpers.getAdditionalInstanceField(p, FIELD);
        if (st != null) schedule(st);
    }

    /** 同一帧里 setSelected 会被调两次（旧的 false、新的 true），合并成一次更新。 */
    static void schedule(State st) {
        if (st.pending || st.row == null) return;
        st.pending = true;
        st.row.post(st.update);
    }

    static void updateIndicator(State st, boolean animate) {
        ViewGroup row = st.row;
        if (row == null || st.d == null || row.getWidth() == 0) return;
        float inset = INDICATOR_H_INSET * row.getResources().getDisplayMetrics().density;

        for (int i = 0; i < row.getChildCount(); i++) {
            View c = row.getChildAt(i);
            if (c.getVisibility() == View.GONE || !tabClass.isInstance(c) || !c.isSelected()) continue;
            if (c.getWidth() == 0) return;
            float tx = c.getTranslationX();
            st.d.moveIndicator(c.getLeft() + tx + inset, c.getRight() + tx - inset, animate);
            return;
        }
        // 没有选中项（过渡中）：保持原位，不闪
    }
}
