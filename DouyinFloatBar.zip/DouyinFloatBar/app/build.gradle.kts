plugins { id("com.android.application") }

android {
    namespace = "io.github.dyfloatbar"
    compileSdk = 34
    defaultConfig {
        applicationId = "io.github.dyfloatbar"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    compileOnly("de.robv.android.xposed:api:82")
}
