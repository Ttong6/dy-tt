# 抖音 40.6.0 悬浮底栏（LSPosed）—— 已按 40600200 写死

样式取自视频：实心胶囊底栏 + 极细描边 + 选中项后面一块滑动的胶囊，无模糊/半透明，不是玻璃态。

## 写死的目标（来自 APK 的 dex + 布局 r/zfh.xml）
| 作用 | 类 / id |
|---|---|
| 底栏本体 | `X.0dx5`（FrameLayout，"MainBottomTabViewNew"） |
| 标签行（胶囊画在这） | 布局 id `0x7f0a7983` |
| 顶部 0.5dp 分割线（隐藏） | 布局 id `0x7f0a75d9` |
| 单个 tab | `com.ss.android.ugc.aweme.homepage.tab.ui.bottom.BottomTab`，父类 `X.0du7` |

不是 40.6.0 时找不到这些类，模块会在日志里写 `[DYFB]` 并自动跳过，不会影响抖音。

## 字体反色
不再强制深色胶囊。App 切到浅色页面时底栏底色会变白、文字图标变深色；模块读取 App 设置的底色，
深色页面用深色胶囊（视频配色），浅色页面用浅色胶囊，所以文字和图标始终清晰，无需改文字颜色。

## 功耗
旧版在底栏上挂了每帧回调，并且每帧遍历 View 树；信息流视频一直在重绘，所以一直在空转。
新版没有任何每帧工作，只 hook 三个方法：
- `X.0dx5.onAttachedToWindow`：安装一次
- `X.0dx5.setBackgroundDrawable`：App 切页面主题时才触发
- `X.0du7.setSelected(boolean)`：切 tab 时才触发，同一帧的两次调用合并成一次更新

动画只在切 tab 的 220ms 内刷新标签行这一小块区域。

## 构建 / 使用
Android Studio 打开本目录 → 构建 debug 包 → LSPosed 启用，作用域勾 `com.ss.android.ugc.aweme` → 强行停止抖音再打开。
边距在 `MainHook.java` 顶部，颜色在 `FloatingBarDrawable.java` 顶部。

## 没生效时
LSPosed 日志搜 `[DYFB]`，把相关几行发我。
